package com.example.listadepresentes.models

data class Gift(
        //      tipo de variável
        var name:String,
        var giftName:String,
        var description:String,

)
