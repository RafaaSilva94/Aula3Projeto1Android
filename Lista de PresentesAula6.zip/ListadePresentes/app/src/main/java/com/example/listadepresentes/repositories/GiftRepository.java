package com.example.listadepresentes.repositories;

import com.example.listadepresentes.models.Gift;

import java.util.ArrayList;

public class GiftRepository {

    private static GiftRepository repository;
    private ArrayList<Gift> gifts = new ArrayList<>();

    public static GiftRepository getInstance(){
        if(repository == null){
            repository = new GiftRepository();

        }
        return repository;

    }

    private GiftRepository(){
    }

    public void save(Gift gift) {
        gifts.add(gift);
    }
    private void delete(Gift gift) {
        gifts.remove(gift);
    }
    public ArrayList<Gift> getAll() {
        return gifts;
    }
    public void update(int index, Gift gift){
        gifts.set(index, gift);
    }
    public Gift getByIndex(int index){
        return gifts.get(index);
    }

}









