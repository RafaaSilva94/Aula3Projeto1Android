package br.com.up.pokedex

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() { //igual extends em JAVA <> Construtor vai na declaracão de classe

//retrofit android = maior biblioteca de aquisição https

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}