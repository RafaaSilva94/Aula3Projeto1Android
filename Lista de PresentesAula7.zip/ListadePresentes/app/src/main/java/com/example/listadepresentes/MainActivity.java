package com.example.listadepresentes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.listadepresentes.adapters.GiftAdapter;
import com.example.listadepresentes.models.Gift;
import com.example.listadepresentes.repositories.GiftRepository;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private FloatingActionButton

    private FloatingActionButton fabAddGift;
    private RecyclerView recyclerViewGifts;

    recyclerViewGifts = findViewById(R.id.recycler_gift);
    fabAddGift = findViewById(R.id.fab_add_gift);

    recyclerViewGifts.setLayoutManager(
          new LinearLayoutManager(context:this,
                           RecyclerView.VERTICAL,
                           reverseLayout:false
                                  )
            /* new GridLayoutManager(this, spanCount: 3) */

     );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fabAddGift = findViewById(R.id.fab_add_gift);

    @Override
    protected void onResume() {
        super.onResume();

        ArrayList<Gift> gifts = GiftRepository.getInstance().getAll();

        if(gifts.size() > 0){

        }

        recyclerViewGifts.setAdapter(new GiftAdapter(gifts));

        }

        ArrayList<Gift> gifts =
                GiftRepository.getInstance().getAll();


        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        };

        fabAddGift.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(
                        getApplicationContext(),
                        AddGiftActivity.class
                );

                startActivity(intent);

            }
        });
    }
}