package com.example.listadepresentes.adapters;

public class GiftAdapter {
}
