package com.example.tela_jogo_appmoveis;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;

import java.util.Random;

public class GiroGarrafa extends AppCompatActivity {
    private ImageView garrafa;
    private Random random = new Random();
    private int ultDir;
    private boolean giro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        garrafa = findViewById(R.id.garrafa);

    }
    public void giraGarrafa(View v) {
        if (!giro) {
            int novaDir = random.nextInt(1800);
            float pivoX = garrafa.getWidth() / 2;
            float pivoY = garrafa.getHeight() / 2;

            Animation rotacao = new RotateAnimation(ultDir, novaDir, pivoX, pivoY);
            rotacao.setDuration(2500);
            rotacao.setFillAfter(true);
            rotacao.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                    giro = true;
                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    giro = false;
                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });

            ultDir = novaDir;
            garrafa.startAnimation(rotacao);

        }

    }
}